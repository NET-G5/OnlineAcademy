﻿using System.Windows;

namespace AcademySystem.Views
{
    /// <summary>
    /// Interaction logic for OnlineCourses.xaml
    /// </summary>
    public partial class OnlineCourses : Window
    {
        public OnlineCourses()
        {
            InitializeComponent();
        }

        private void Buy_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
